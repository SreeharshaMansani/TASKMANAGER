# Task Assistant widget

A separately built React widget. This package owns the launcher, conversation UI, styles, request handling and session cleanup. It has no Task Manager source imports, router dependency, local-storage assumptions or login screen.

## Build and test independently

```powershell
cd C:\Users\Dell\Desktop\chatbot\widget
npm install
npm test
npm run build
npm pack
```

The output is `task-assistant-widget-1.0.2.tgz`. It contains compiled JavaScript, CSS and TypeScript declarations. It is a local package, not a published npm release. React and React DOM are supplied by the host application.

## Install in a host application

Copy the tarball into the host's `vendor` directory, then run:

```powershell
npm install ./vendor/task-assistant-widget-1.0.2.tgz
```

The installed application does not need the chatbot source directory. The chatbot API can run on a separate machine. Configure its URL explicitly:

```jsx
import { TaskAssistantWidget } from '@task-assistant/widget';
import '@task-assistant/widget/styles.css';

// Create this adapter once, outside rendering. Use your application's session store.
const auth = {
  getToken: () => applicationSession.getAccessToken() || null,
  subscribe: listener => applicationSession.subscribe(listener),
};

function App() {
  return <>
    <YourApplication />
    <TaskAssistantWidget
      apiUrl="https://assistant-api.example.com"
      auth={auth}
      onTasksChanged={executions => refreshAffectedTaskLists(executions)}
    />
  </>;
}
```

`applicationSession` and `refreshAffectedTaskLists` above are host-provided functions, not widget globals. `auth.subscribe(listener)` must return an unsubscribe function and notify listeners immediately on login, logout, token refresh or account change. `getToken()` is synchronous and returns the current token or `null`. Mount one widget per page. The Task Manager adapter is included in `../integrations/taskmanager/TaskAssistant.jsx`.

## Automatic authentication

1. The user signs in to the host application normally.
2. The host adapter supplies the current user's session token to the widget.
3. The widget sends it only to the configured chatbot API as an `Authorization: Bearer` header. It does not store the token or put it in a URL or prompt.
4. The chatbot backend verifies the session with the host API before accepting a message. Task tools run with that same user's permissions.
5. Logout or account/token changes unmount the current conversation, abort pending browser requests and clear its history. Responses from an old session are ignored. Aborting a browser request does not undo a task action already accepted by the server.

For this deployment, the server uses `TASK_BACKEND_URL` and Task Manager's `/auth/getuser` endpoint to verify tokens. A different application needs a server-side authentication/tool adapter compatible with its API. Installing the UI alone cannot make unrelated APIs or credential formats compatible.

An application API key is not a substitute for identifying the signed-in user. Do not pass passwords, JWT signing secrets, provider keys or private application keys into the widget. Keep private credentials on the backend. Hosts using HttpOnly sessions can expose a server-side exchange for a short-lived, user-scoped widget token; that exchange is not implemented by this package.

Set `FRONTEND_ORIGIN` on the chatbot server to the permitted host origin, and use HTTPS for deployed services. No second user login is required.

## Styling

Styles use `.chat-*` class names and widget theme variables with their own defaults. They are ordinary CSS, not Shadow DOM isolation. Optional variables such as `--task-assistant-primary`, `--task-assistant-bg-secondary` and `--task-assistant-font-main` customize the appearance without requiring the host's stylesheet.

## Standalone scope and request trace

By default, the widget checks the chatbot API's `/health` endpoint when a signed-in session mounts, every 15 seconds, and when the browser returns online or regains focus. The composer and example buttons remain disabled while availability is being checked or the API is offline. An offline panel offers an immediate retry, and the widget reconnects automatically after the API starts. Hosts may set `availabilityCheck={false}` only when they provide their own availability handling.

This is an independently built React library, not a standalone website. It has no `npm start` script or login screen. The chatbot API runs separately from the repository root; a host must mount this widget and supply a valid session. Current authentication and task tools use the Task Manager backend.

The backend verifies each chat request through the host profile API and supplies the verified display name to the model. A personalized greeting may show "No tool was called" because that trace lists only model-selected tool executions, not authentication requests. Retrieved tools are candidates, not executed operations, and similarity scores are not confidence percentages.

## Updating

Rebuild and pack a new widget version, replace the host's tarball, and reinstall that package. There is no sibling source-directory import or symlink. The host keeps only its session/refresh adapter; chat UI development stays in this project.

